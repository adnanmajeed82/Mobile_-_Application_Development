package com.example.itcollege;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.itcollege.AppDB;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText name, phone;
    Button save, show;
    AppDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name  = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        save  = findViewById(R.id.save);
        show  = findViewById(R.id.show);

        db = Room.databaseBuilder(this, AppDB.class, "admission.db")
                .allowMainThreadQueries()
                .build();

        save.setOnClickListener(v -> {
            Student s = new Student();
            s.name = name.getText().toString();
            s.phone = phone.getText().toString();
            s.course = "BSCS";

            db.studentDao().insert(s);
            Toast.makeText(this, "Admission Saved!", Toast.LENGTH_SHORT).show();
            name.setText("");
            phone.setText("");
        });

        show.setOnClickListener(v -> {
            List<Student> list = db.studentDao().getAll();
            StringBuilder sb = new StringBuilder();

            for(Student s : list) {
                sb.append(s.id).append(". ").append(s.name).append(" (").append(s.phone).append(")\n");
            }

            Toast.makeText(this, sb.toString(), Toast.LENGTH_LONG).show();
        });
    }
}
